extends Area2D

@onready var block: Sprite2D = $Block
@onready var block_2: Sprite2D = $Block2


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_body_entered(body: Node2D) -> void:
	block_2.position.y -= 200
	block.position.y -= 200
	$StaticBody2D.position.y -= 200
	$CollisionShape2D.position.y -= 200
	$AudioStreamPlayer.play()
	await get_tree().create_timer(0.26).timeout
	$AudioStreamPlayer.stop()
	pass # Replace with function body.
