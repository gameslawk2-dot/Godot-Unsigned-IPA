extends Area2D


func _on_down_up_spike_body_entered(body: Node2D) -> void:
	$AudioStreamPlayer.play()
	await get_tree().create_timer(0.23).timeout
	get_tree().reload_current_scene()
	pass # Replace with function body.


func _on_body_entered(body: Node2D) -> void:
	$"Down Up Spike/UpSpike".position.y += 90
	$"Down Up Spike/UpSpike2".position.y += 90
	$"Down Up Spike/CollisionPolygon2D".position.y += 90
	$AudioStreamPlayer3.play()
	await get_tree().create_timer(0.26).timeout
	$AudioStreamPlayer3.stop()
	queue_free()
	pass # Replace with function body.
