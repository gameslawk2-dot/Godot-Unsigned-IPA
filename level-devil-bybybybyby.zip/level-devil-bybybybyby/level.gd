extends Node2D

var speedl = -100
var speedr = 100
var jump = -200

func _on_win_1_body_entered(body: Node2D) -> void:
	$AudioStreamPlayer2.play()
	$player.position.x = 126.0
	$player.position.y = 278.0
	$Camera2D.enabled = false
	$Camera2D2.enabled = true
	$TouchScreenButton.position.y = 288
	$TouchScreenButton2.position.y = 288
	$TouchScreenButton3.position.y = 288
	pass # Replace with function body.


func _on_dead_body_entered(body: Node2D) -> void:
	$AudioStreamPlayer.play()
	await get_tree().create_timer(0.23).timeout
	get_tree().reload_current_scene()
	pass # Replace with function body.


func _on_win_2_body_entered(body: Node2D) -> void:
	$TouchScreenButton.position.y = 448
	$TouchScreenButton2.position.y = 448
	$TouchScreenButton3.position.y = 448
	$Camera2D2.enabled = false
	$Camera2D3.enabled = true
	$player.position.y = 438.0
	$player.position.x = 84.0
	$AudioStreamPlayer2.play()
	pass # Replace with function body.


func _on_win_3_body_entered(body: Node2D) -> void:
	$player.position.x = 423.0
	$player.position.y = 117.0
	$TouchScreenButton.position.x += 358
	$TouchScreenButton2.position.x += 358
	$TouchScreenButton3.position.x += 358
	$Camera2D3.enabled = false
	$Camera2D4.enabled = true
	$AudioStreamPlayer2.play()
	pass # Replace with function body.

func _on_win_4_body_entered(body: Node2D) -> void:
	$player.position.y = 278.0
	$player.position.x = 420.0
	$TouchScreenButton.position.y = 288
	$TouchScreenButton2.position.y = 288
	$TouchScreenButton3.position.y = 288
	$Camera2D4.enabled = false
	$Camera2D5.enabled = true
	$AudioStreamPlayer2.play()
	pass # Replace with function body.


func _on_door_do_nothing_body_entered(body: Node2D) -> void:
	$Win3.position.x = 125
	$AudioStreamPlayer3.play()
	await get_tree().create_timer(0.26).timeout
	$AudioStreamPlayer3.stop()
	pass # Replace with function body.
