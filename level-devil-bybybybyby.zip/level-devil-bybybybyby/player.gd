extends CharacterBody2D

var speed = 60
var jump = -200

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta
	if Input.is_action_just_pressed("ui_up") and is_on_floor():
		velocity.y = jump
	move()
	move_and_slide()
	pass

func move():
	var direction := Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * speed
		sound()
	else:
		velocity.x = move_toward(velocity.x, 0, speed)
	
	if Input.is_action_pressed("ui_right"):
		$AnimationPlayer.play("Walk")
		$Sprite2D.flip_h = false
	if Input.is_action_pressed("ui_left"):
		$AnimationPlayer.play("Walk")
		$Sprite2D.flip_h = true
	
	pass

func sound():
	if $Timer.time_left <= 0:
		$walk_sfx.pitch_scale = randf_range(0.8,1.2)
		
		$walk_sfx.stream = load("res://Sfx/footstep_grass_004.ogg")
		
		$walk_sfx.play()
		$Timer.start(0.4)
	pass
