extends Area2D

var b = 32

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_body_entered(body: Node2D) -> void:
	$CollisionPolygon2D.queue_free()
	$Block4.position.y = 40
	$Block5.position.y = 56
	$Block6.position.y = 40
	$Block7.position.y = 56
	$Block8.position.y = 56
	$Block9.position.y = 40
	$Block10.position.y = 56
	$Block11.position.y = 40
	$StaticBody2D.position.y = -32
	$AudioStreamPlayer3.play()
	await get_tree().create_timer(0.26).timeout
	$AudioStreamPlayer3.stop()
	pass # Replace with function body.
